
# AI Mood-Based Playlist Generator - Implementation Guide

## Project Structure
```
mood-playlist-generator/
├── frontend/                    # React.js application
│   ├── src/
│   │   ├── components/
│   │   │   ├── MoodInput.jsx
│   │   │   ├── PlaylistView.jsx
│   │   │   ├── MusicPlayer.jsx
│   │   │   └── AuthWrapper.jsx
│   │   ├── services/
│   │   │   ├── api.js
│   │   │   └── spotify.js
│   │   ├── hooks/
│   │   │   └── useMoodAnalysis.js
│   │   └── App.jsx
│   ├── package.json
│   └── .env.local
├── backend/                     # Node.js/Express API
│   ├── src/
│   │   ├── controllers/
│   │   │   ├── moodController.js
│   │   │   └── playlistController.js
│   │   ├── services/
│   │   │   ├── geminiService.js
│   │   │   └── spotifyService.js
│   │   ├── middleware/
│   │   │   └── auth.js
│   │   └── app.js
│   ├── package.json
│   └── .env
└── README.md
```

## Key Implementation Components

### 1. Frontend - React.js with Mood Input
```jsx
// components/MoodInput.jsx
import React, { useState } from 'react';
import { useMoodAnalysis } from '../hooks/useMoodAnalysis';

const MoodInput = ({ onPlaylistGenerated }) => {
  const [moodText, setMoodText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { analyzeMood, generatePlaylist } = useMoodAnalysis();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const moodData = await analyzeMood(moodText);
      const playlist = await generatePlaylist(moodData);
      onPlaylistGenerated(playlist);
    } catch (error) {
      console.error('Error generating playlist:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="mood-input">
      <textarea
        value={moodText}
        onChange={(e) => setMoodText(e.target.value)}
        placeholder="Describe your mood or what you're feeling..."
        rows={4}
        required
      />
      <button type="submit" disabled={isLoading}>
        {isLoading ? 'Generating...' : 'Generate Playlist'}
      </button>
    </form>
  );
};

export default MoodInput;
```

### 2. Backend - Gemini AI Integration
```javascript
// services/geminiService.js
const { GoogleGenAI } = require('@google/genai');

class GeminiService {
  constructor() {
    this.client = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY
    });
  }

  async analyzeMood(userInput) {
    const prompt = `
    Analyze the following mood description and extract:
    1. Primary emotion (happy, sad, excited, calm, angry, nostalgic, etc.)
    2. Energy level (high, medium, low)
    3. Musical preferences (genre, tempo, instrumental vs vocal)
    4. Specific keywords for song search

    User input: "${userInput}"

    Respond in JSON format with: {
      "emotion": "primary_emotion",
      "energy": "energy_level",
      "genres": ["genre1", "genre2"],
      "tempo": "fast/medium/slow",
      "keywords": ["keyword1", "keyword2"],
      "valence": 0.8,  // 0-1 scale for positivity
      "danceability": 0.6  // 0-1 scale for danceability
    }
    `;

    try {
      const response = await this.client.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt
      });

      return JSON.parse(response.text);
    } catch (error) {
      throw new Error(`Gemini analysis failed: ${error.message}`);
    }
  }
}

module.exports = new GeminiService();
```

### 3. Spotify Integration Service
```javascript
// services/spotifyService.js
const SpotifyWebApi = require('spotify-web-api-node');

class SpotifyService {
  constructor() {
    this.spotify = new SpotifyWebApi({
      clientId: process.env.SPOTIFY_CLIENT_ID,
      clientSecret: process.env.SPOTIFY_CLIENT_SECRET,
      redirectUri: process.env.SPOTIFY_REDIRECT_URI
    });
  }

  async searchTracks(moodData, limit = 20) {
    const { genres, keywords, valence, energy, tempo } = moodData;

    // Build search query
    const genreQuery = genres.map(g => `genre:${g}`).join(' OR ');
    const keywordQuery = keywords.join(' ');
    const searchQuery = `${keywordQuery} ${genreQuery}`;

    try {
      const searchResults = await this.spotify.searchTracks(searchQuery, {
        limit,
        market: 'US'
      });

      // Get audio features for better matching
      const trackIds = searchResults.body.tracks.items.map(track => track.id);
      const audioFeatures = await this.spotify.getAudioFeaturesForTracks(trackIds);

      // Filter tracks based on mood characteristics
      const filteredTracks = searchResults.body.tracks.items.filter((track, index) => {
        const features = audioFeatures.body.audio_features[index];
        if (!features) return false;

        const valenceMatch = Math.abs(features.valence - valence) < 0.3;
        const energyMatch = Math.abs(features.energy - energy) < 0.3;

        return valenceMatch && energyMatch;
      });

      return filteredTracks.slice(0, 15); // Return top 15 matches
    } catch (error) {
      throw new Error(`Spotify search failed: ${error.message}`);
    }
  }

  async createPlaylist(userId, playlistName, tracks) {
    try {
      const playlist = await this.spotify.createPlaylist(userId, {
        name: playlistName,
        description: 'Generated by AI Mood-Based Playlist Generator',
        public: false
      });

      const trackUris = tracks.map(track => track.uri);
      await this.spotify.addTracksToPlaylist(playlist.body.id, trackUris);

      return playlist.body;
    } catch (error) {
      throw new Error(`Playlist creation failed: ${error.message}`);
    }
  }
}

module.exports = new SpotifyService();
```

### 4. Authentication with Clerk
```jsx
// components/AuthWrapper.jsx
import { ClerkProvider, SignedIn, SignedOut, SignInButton, UserButton } from '@clerk/clerk-react';

const AuthWrapper = ({ children }) => {
  return (
    <ClerkProvider publishableKey={process.env.REACT_APP_CLERK_PUBLISHABLE_KEY}>
      <header>
        <SignedOut>
          <SignInButton mode="modal" />
        </SignedOut>
        <SignedIn>
          <UserButton />
        </SignedIn>
      </header>

      <SignedIn>
        {children}
      </SignedIn>

      <SignedOut>
        <div className="welcome-screen">
          <h1>AI Mood-Based Playlist Generator</h1>
          <p>Sign in to generate personalized playlists based on your mood!</p>
        </div>
      </SignedOut>
    </ClerkProvider>
  );
};

export default AuthWrapper;
```

### 5. Custom Hook for Mood Analysis
```javascript
// hooks/useMoodAnalysis.js
import { useState } from 'react';
import { apiService } from '../services/api';

export const useMoodAnalysis = () => {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [error, setError] = useState(null);

  const analyzeMood = async (moodText) => {
    setIsAnalyzing(true);
    setError(null);

    try {
      const response = await apiService.post('/api/mood/analyze', {
        moodText
      });
      return response.data;
    } catch (err) {
      setError(err.message);
      throw err;
    } finally {
      setIsAnalyzing(false);
    }
  };

  const generatePlaylist = async (moodData) => {
    try {
      const response = await apiService.post('/api/playlist/generate', {
        moodData
      });
      return response.data;
    } catch (err) {
      setError(err.message);
      throw err;
    }
  };

  return {
    analyzeMood,
    generatePlaylist,
    isAnalyzing,
    error
  };
};
```

### 6. Environment Variables Setup
```bash
# Frontend (.env.local)
REACT_APP_API_BASE_URL=http://localhost:3001
REACT_APP_CLERK_PUBLISHABLE_KEY=pk_test_...

# Backend (.env)
PORT=3001
GEMINI_API_KEY=your_gemini_api_key
SPOTIFY_CLIENT_ID=your_spotify_client_id
SPOTIFY_CLIENT_SECRET=your_spotify_client_secret
SPOTIFY_REDIRECT_URI=http://localhost:3000/callback
CLERK_PUBLISHABLE_KEY=pk_test_...
CLERK_SECRET_KEY=sk_test_...
NODE_ENV=development
```

### 7. Package.json Dependencies

#### Frontend Dependencies
```json
{
  "dependencies": {
    "@clerk/clerk-react": "^4.30.0",
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "axios": "^1.6.0",
    "react-router-dom": "^6.8.0"
  }
}
```

#### Backend Dependencies
```json
{
  "dependencies": {
    "express": "^4.18.2",
    "cors": "^2.8.5",
    "helmet": "^7.1.0",
    "dotenv": "^16.3.1",
    "@google/genai": "^0.7.0",
    "spotify-web-api-node": "^5.0.2",
    "@clerk/express": "^0.12.0"
  }
}
```
